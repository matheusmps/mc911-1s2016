import sys
from lyaParser import LyaParser

p = LyaParser()

p.testLexer("tests/mTest.lya")

