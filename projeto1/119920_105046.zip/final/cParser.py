from lyaParser import LyaParser

p = LyaParser()
